import 'package:flutter/material.dart';

String baseUrl = "http://3.141.66.171/ConnectWorld/";
String imgUrl = "http://3.141.66.171/";

String header = "CONNECTWORLD123";

String? name;
String? token;

String? userId;
String? companyName;
String? agentProfile;
